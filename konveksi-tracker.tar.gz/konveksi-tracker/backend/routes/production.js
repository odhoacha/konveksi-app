const express = require('express');
const db = require('../db/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

const STAGES = ['Potong','Jahit','Pasang Kancing','Finishing','QC','Gosok & Packing','Gudang'];

// GET /api/production — semua log (bisa filter by order_id)
router.get('/', (req, res) => {
  const { order_id } = req.query;
  let query = `
    SELECT pl.*, o.product_name, o.order_code, u.name AS operator_name
    FROM production_logs pl
    JOIN orders o ON o.id = pl.order_id
    LEFT JOIN users u ON u.id = pl.created_by
  `;
  const params = [];
  if (order_id) { query += ' WHERE pl.order_id = ?'; params.push(order_id); }
  query += ' ORDER BY pl.id DESC';

  res.json(db.prepare(query).all(...params));
});

// POST /api/production — input log produksi
router.post('/', (req, res) => {
  const { order_id, stage, qty_in, qty_out, note } = req.body;

  // ── Basic validation
  if (!order_id || !stage || qty_in == null || qty_out == null)
    return res.status(400).json({ error: 'Semua field wajib diisi' });

  if (!STAGES.includes(stage))
    return res.status(400).json({ error: 'Tahap tidak valid' });

  if (qty_out > qty_in)
    return res.status(400).json({ error: 'Qty Keluar tidak boleh lebih besar dari Qty Masuk' });

  if (qty_in < 0 || qty_out < 0)
    return res.status(400).json({ error: 'Qty tidak boleh negatif' });

  // ── Order must exist
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(order_id);
  if (!order) return res.status(404).json({ error: 'Order tidak ditemukan' });
  if (order.status === 'selesai')
    return res.status(400).json({ error: 'Order ini sudah selesai' });

  // ── Stage order validation
  const lastLog = db.prepare(`
    SELECT stage FROM production_logs
    WHERE order_id = ? ORDER BY id DESC LIMIT 1
  `).get(order_id);

  const expectedIndex = lastLog ? STAGES.indexOf(lastLog.stage) + 1 : 0;
  const inputIndex    = STAGES.indexOf(stage);

  if (inputIndex !== expectedIndex) {
    const expected = STAGES[expectedIndex] || '(sudah selesai semua tahap)';
    return res.status(400).json({
      error: `Urutan tahap salah! Tahap berikutnya harus: "${expected}". Input: "${stage}"`
    });
  }

  // ── Insert log
  const result = db.prepare(`
    INSERT INTO production_logs (order_id, stage, qty_in, qty_out, note, created_by)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(order_id, stage, qty_in, qty_out, note || '', req.user.id);

  // ── Auto-complete order jika sudah Gudang
  if (stage === 'Gudang') {
    db.prepare(`UPDATE orders SET status = 'selesai' WHERE id = ?`).run(order_id);
  }

  const log = db.prepare(`
    SELECT pl.*, u.name AS operator_name
    FROM production_logs pl LEFT JOIN users u ON u.id = pl.created_by
    WHERE pl.id = ?
  `).get(result.lastInsertRowid);

  res.status(201).json(log);
});

// DELETE /api/production/:id (superadmin only)
router.delete('/:id', authorize('superadmin'), (req, res) => {
  const log = db.prepare('SELECT * FROM production_logs WHERE id = ?').get(req.params.id);
  if (!log) return res.status(404).json({ error: 'Log tidak ditemukan' });

  db.prepare('DELETE FROM production_logs WHERE id = ?').run(req.params.id);
  res.json({ message: 'Log berhasil dihapus' });
});

module.exports = router;
